from __future__ import unicode_literals
from django.db import models
from django.utils.translation import ugettext_lazy as _


#need to add location for spacfic location advert 
class user(models.Model):

    TYPE_OF_T = (
        ('mael', 'mael'),
        ('fimael', 'fimel'),
    )
    T_type = models.CharField(_('Type'), max_length=100, choices=TYPE_OF_T, default='')
    u_id = models.AutoField(_('Concert Id'), primary_key=True, unique=True, max_length=20)
    r_day = models.DateTimeField(_('register day'), auto_now_add=True, )
    name = models.CharField(_('Name'), default='', unique=False, max_length=20)
    f_name = models.CharField(_('f name'), max_length=200, default='')
    phone = models.CharField(_('phone Number'), max_length=200, default='')


class docter(models.Model):

    TYPE_OF_T = (
        ('mael', 'mael'),
        ('fimael', 'fimel'),
    )
    T_type = models.CharField(_('Type'), max_length=100, choices=TYPE_OF_T, default='')
    D_id = models.AutoField(_('Concert Id'), primary_key=True, unique=True, max_length=20)
    r_day = models.DateTimeField(_('register day'), auto_now_add=True, )
    name = models.CharField(_('Name'), default='', unique=False, max_length=20)
    f_name = models.CharField(_('f name'), max_length=200, default='')
    phone = models.CharField(_('phone Number'), max_length=200, default='')


class chat(models.Model):

    rq_id = models.AutoField(_('Concert Id'), primary_key=True, unique=True, max_length=20)
    r_day = models.DateTimeField(_('register day'), auto_now_add=True, )
    respond = models.TextField(_('respond'), default='', unique=False,)
    requst = models.TextField(_('request'), default='')
    user = models.ForeignKey(user, default='', on_delete=models.CASCADE)
    docter = models.ForeignKey(docter, default='', on_delete=models.CASCADE)


class commet(models.Model):

    rq_id = models.AutoField(_('Concert Id'), primary_key=True, unique=True, max_length=20)
    r_day = models.DateTimeField(_('register day'), auto_now_add=True, )
    comment = models.TextField(_('comment'), default='')
    user = models.ForeignKey(user, default='', on_delete=models.CASCADE)

class setAlarem(models.Model):

    ar_id = models.AutoField(_('Concert Id'), primary_key=True, unique=True, max_length=20)
    docter = models.ForeignKey(docter, default='', on_delete=models.CASCADE)
    user = models.ForeignKey(user, default='', on_delete=models.CASCADE)
    r_day = models.DateTimeField(_('register day'), auto_now_add=True, )
    info = models.TextField(_('info'), default='')
    startday = models.DateTimeField(_('start time'), default='')
    endingday = models.DateTimeField(_('end time'), default='')
    time1 = models.TimeField(_('taking time1'), default='')
    time2 = models.TimeField(_('taking time2'), default='')