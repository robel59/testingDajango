from django import forms
from .models import *


class UserForm(forms.ModelForm):
    #password1 = forms.CharField(label='Password', widget=forms.PasswordInput)
    #password2 = forms.CharField(label='Password confirmation', widget=forms.PasswordInput)

    class Meta:
        model = user
        fields = ('name','phone',)


class LogIn(forms.Form):
    name = forms.CharField()
    phone = forms.CharField()
class LogIn1(forms.Form):
    phone = forms.CharField()
    comment = forms.CharField()
class pay_form(forms.Form):
    money_to_send = forms.DecimalField(max_digits=10, decimal_places=5)
    phone_number = forms.CharField()
