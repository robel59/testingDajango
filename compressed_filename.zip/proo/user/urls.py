from django.conf.urls import url,include
from django.conf import settings
from .views import *
from django.conf.urls.static import static

urlpatterns = [
	
    url(r'^chat/$', new_comment),
    url(r'^register/$', registeNewUser),
    url(r'^pre/$', new_pre),

    url(r'^notif/$', new_comment),
    url(r'^index/$', UserFormView.as_view()),
    url(r'^com/$', UserFormView2.as_view()),
    url(r'^lop/$', UserFormView3.as_view()),
    url(r'^lo/$', UserFormView4.as_view()),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)