from rest_framework import serializers
from .models import *


class SnippetSerializer_user(serializers.ModelSerializer):
    class Meta:
        model = user
        fields = ('u_id', 'name', 'f_name', 'phone')



class SnippetSerializer_chat(serializers.ModelSerializer):
    class Meta:
        model = chat
        fields = ('rq_id', 'r_day')

class SnippetSerializer_chatm(serializers.ModelSerializer):
    class Meta:
        model = chat
        fields = ('rq_id','respond', 'r_day')


class SnippetSerializer_setT(serializers.ModelSerializer):
    class Meta:
        model = setAlarem
        fields = ('ar_id', 'info','startday', 'endingday', 'time1', 'time2')