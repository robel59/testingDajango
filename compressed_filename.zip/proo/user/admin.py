from django.contrib import admin
from .models import *


class custamer(admin.ModelAdmin):
    list_display = (
    'u_id', 'name', 'T_type','phone')
    search_fields = ('u_id',)
    ordering = ('u_id',)


class docters(admin.ModelAdmin):
    list_display = (
    'D_id', 'name', 'T_type','phone')
    search_fields = ('D_id',)
    ordering = ('D_id',)


class chat1(admin.ModelAdmin):
    list_display = (
    'rq_id', 'respond', 'requst')
    search_fields = ('rq_id',)
    ordering = ('rq_id',)

class coment(admin.ModelAdmin):
    list_display = (
    'rq_id', 'comment',)
    search_fields = ('rq_id',)
    ordering = ('rq_id',)
class take(admin.ModelAdmin):
    list_display = (
    'ar_id', 'r_day',)
    search_fields = ('ar_id',)
    ordering = ('ar_id',)
admin.site.register(user, custamer)
admin.site.register(setAlarem, take)
admin.site.register(docter, docters)
admin.site.register(chat, chat1)
admin.site.register(commet, coment)