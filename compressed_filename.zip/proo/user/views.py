
from django.shortcuts import render, redirect, render_to_response
from django.http import HttpResponseRedirect, JsonResponse, HttpResponse
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import View
from rest_framework.parsers import JSONParser
from .serial import *
from django import forms
from .models import *
from .forms import *


@csrf_exempt
def registeNewUser(request):
    print("pass these point")
    a="usee aldy register"
    if request.method == 'POST':
        data = JSONParser().parse(request)
        name = data["name"]
        #typee = data["type"]
        f_name = data["f_name"]
        phone = data["phone"]
        typee = data["type"]
        print(phone)
        try:
            us = user.objects.get(phone=phone)
            serializer = SnippetSerializer_user(us, many=False)
            print(serializer)
            return JsonResponse(serializer.data, safe=False) 
        except user.DoesNotExist:
            tuy = user(T_type=typee, name=name, f_name=f_name, phone=phone)
            print("not here")
            tuy.save()
            serializer = SnippetSerializer_user(tuy, many=False)
            print(serializer)
            return JsonResponse(serializer.data, safe=False) 


@csrf_exempt
def new_comment(request):
    print("pass these point")
    a="usee aldy register"
    if request.method == 'POST':
        data = JSONParser().parse(request)
        com = data["rq"]
        a_i=data["id"]
        print(com)
        print(a_i)
        ho = user.objects.get(u_id=a_i)
        us = docter.objects.get(D_id=1)
        
        tuy = chat(respond="", requst=com, user=ho, docter=us)
        tuy.save()
        serializer = SnippetSerializer_chat(tuy, many=False)
        return JsonResponse(serializer.data, safe=False) 
    return HttpResponse(status=204)

@csrf_exempt
def new_comment(request):
    print("pass these point")
    a="usee aldy register"
    if request.method == 'POST':
        data = JSONParser().parse(request)
        com = data["not_id"]
        ho = user.objects.filter(rq_id__gt=com)
       
        serializer = SnippetSerializer_chatm(tuy, many=False)
        return JsonResponse(serializer.data, safe=False) 
    return HttpResponse(status=204)

@csrf_exempt
def new_pre(request):
    if request.method == 'POST':
        data = JSONParser().parse(request)
        com = data["not_id"]
        print(com)
        ho = user.objects.get(u_id=com)
        kol = setAlarem.objects.get(user = ho)
        print(kol.ar_id)
        serializer = SnippetSerializer_setT(kol, many=False)
        return JsonResponse(serializer.data, safe=False) 
    return HttpResponse(status=204)

class UserFormView(View):
    form_class = LogIn
    form_class2 = LogIn1
    tem_name = 'index.html'
    tem_name1 = 'new.html'

    def get(self, request):
        form = self.form_class(None)
        form1 = self.form_class2(None)
        g = commet.objects.all()
        return render(request, self.tem_name, {'form': form, 'form1': form1, 'g':g})

    def post(self, request):
        form = self.form_class(request.POST)
        form1 = self.form_class2(request.POST)
        print("JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ")

        if form1.is_valid():
            print("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
            #user = form.save(commit=False)

            phone = form1.cleaned_data['phone']
            print(name1)
            com = form1.cleaned_data['comment']
            print(phone_number)
            dd = user.objects.get(phone=phone)
            print(dd)
            if dd is not None:
                r = commet(comment=com, user=dd)
                r.save()
                g = comment.objects.all()
                print(g)
                return render(request, self.tem_name, {'form': form, 'form1': form1, 'g':g})
        if form.is_valid():
            print("fffffffffffffffffffffffffffffff")
            #user = form.save(commit=False)

            name1 = form.cleaned_data['name']
            print(name1)
            phone_number = form.cleaned_data['phone']
            print(phone_number)
            dd = user.objects.get(phone=phone_number)
            print(dd)
            if dd is not None:
                t = chat.objects.filter(user=dd)
             
                return render(request, "t_actionuser_list..html", {'t':t})


        return render(request, self.tem_name1, {'form': form}, {'form1': form1})

class UserFormView2(View):
    form_class2 = LogIn1
    tem_name = 'comentDis.html'
    tem_name1 = 'new.html'

    def get(self, request):
        form1 = self.form_class2(None)
        g = commet.objects.all()
        return render(request, self.tem_name, {'g':g, 'form1': form1})
    def post(self, request):
        form1 = self.form_class2(request.POST)

        if form1.is_valid():
            #user = form.save(commit=False)

            phone = form1.cleaned_data['phone']
            com = form1.cleaned_data['comment']
            dd = user.objects.get(phone=phone)
            print(dd)
            if dd is not None:
                r = commet(comment=com, user=dd)
                r.save()
                g = commet.objects.all()
                print(g)
                return render(request, "comentDis.html", {'g': g})


class UserFormView3(View):
    form_class = LogIn
    form_class2 = LogIn1
    tem_name = 'app1.html'
    tem_name1 = 'new.html'

    def get(self, request):
        return render(request, self.tem_name)

class UserFormView4(View):
    tem_name = 'app2.html'

    def get(self, request):
        return render(request, self.tem_name)